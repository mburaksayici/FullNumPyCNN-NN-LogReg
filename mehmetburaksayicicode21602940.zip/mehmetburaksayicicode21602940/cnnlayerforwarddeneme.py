import numpy as np


import mnist
import numpy as np
import matplotlib.pyplot as plt




#Data Prep---
x_train, y_train, x_test, y_test = mnist.load()
x_train = x_train.reshape(-1,28*28)


numbofimages = 60000
mnistx = x_train/255
mnisty = y_train.reshape(1,numbofimages)
b = np.zeros((numbofimages,10)) # 10 is number of classes
b[np.arange(numbofimages), mnisty] = 1
mnisty = b
#---


weightcnn1 = np.random.normal(0,0.01,(20,3,3))
weightfcn = np.random.normal(0,0.01,(13520,10))
bfcn = np.random.normal(0,0.2,(1,10))










def relu(x):
    x.copy()
    out = x*(x > 0)
    return out




def cceforward(x,y,w1,w2,lambdaa = 1,reg = "CCE",):
    if reg == "CCE":
        return np.sum(-y * np.log(x + 1e-15) / x.shape[0])
    elif  reg == "CCEL2":
        return np.sum(-y * np.log(x  + 0) / x.shape[0]) + lambdaa*np.sum(np.square(w1))
    elif reg == "CCEL1":
        return np.sum(-y * np.log(x  + 0) / x.shape[0]) + lambdaa*np.sum(np.abs(w1))  +lambdaa*np.sum(np.abs(w2))




def softmax(x):
    return np.exp(x)/np.sum(np.exp(x),axis=1,keepdims=True)




def ForwardConv(inputarray, stride, weights, flatten = False):
    filternumber = weights.shape[0]
    height = weights.shape[1]
    width = weights.shape[2]
    stride = stride
    numbofimagesinputarray = inputarray.shape[0]

    print("Input Array Shape for Conv : ", inputarray.shape)
    hoffmap = inputarray[0].shape[0]  # hoffmap -> height of feature map

    woffmap = inputarray[0].shape[1]  # woffmap -> width of feature map

    widthtour = int(1 + (woffmap - width) / stride)
    print(widthtour)
    heighttour = int(1 + (hoffmap - height) / stride)
    # print(widthtour)
    # print(heighttour)
    featuremap = np.zeros((inputarray.shape[0], filternumber, widthtour, heighttour))

    for i in range(inputarray.shape[0]):
        for j in range(filternumber):
            for k in range(int(heighttour)):
                for l in range(int(widthtour)):
                    # if channel is implemented  we need another for loop for channel
                    # print(stride*l,width+stride*(l),"---")
                    array_ = inputarray[i][stride * k:height + stride * k,
                                  stride * l:width + stride * l]

                    # print(inputarray[i][l:height,width*l:width*(l+1)].shape)
                    # print(i, j, k, l)
                    featuremap[i, j, k, l] = np.sum(np.multiply(array_, weights[j]))
    if flatten== False:
        return featuremap.reshape(-1,k+1,l+1)
    else:
        return featuremap.reshape(numbofimagesinputarray,-1)




def train(losstype="CCE",lr=0.001, epoch= 10,  batchsize=32, weightdecay = 1,weightdecayperiod= 10,node=10,
          randomweights = True)  :

    traininglosstable = np.array([])

    for i in range(epoch):

        if i % weightdecayperiod == 0 and i > 1:
            lr = lr * weightdecay

        trainingepochaccuracy = 0
        lambdaa = 5e-6

        repet = int(6400 / batchsize)

        for a in range(repet):

            mnistxtrain = mnistx[batchsize * a:(batchsize * (a + 1))].reshape(-1,28,28)
            mnistytrain = mnisty[batchsize * a:(batchsize * (a + 1))]


            cnnout = ForwardConv(mnistxtrain, 1, weightcnn1, flatten=True)
            print(cnnout.shape)
            relucnnout = relu(cnnout)
            logout =  np.dot(relucnnout,weightfcn) + bfcn
            pred = softmax(logout)



    print(epoch,"epoch")



train()




"""
b = ForwardConv(a,2,weightcnn2)

print(b.shape,"b")


np.convolve(mnistx[0],)


plt.imshow(mnistx[0].reshape(28,28))
plt.show()
plt.imshow(a[0])
plt.show()
plt.imshow(b[0])
plt.show()
"""